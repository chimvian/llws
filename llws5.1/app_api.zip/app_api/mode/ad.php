﻿<?php
$u = $_GET["username"];
$p = $_GET["password"];
$res=db(_openvpn_)->where(array(_iuser_=>$u,_ipass_=>$p))->find();
if(!$res){
	die("登录信息错误");
}
if(isset($_POST['km'])){
	$km = $_POST['km'];
	$myrow=db("auth_kms")->where(array("kind"=>"1","km"=>$km))->find();
	if(!$myrow){
		die('此激活码不存在');
	}elseif($myrow['isuse']==1){
		die('此激活码已被使用');
	}else{
		$duetime = time() + $myrow['value']*24*60*60;
		$addll = $myrow['values']*1024*1024*1024;
		//已到期 清空全部流量
		$update[_maxll_] = $addll;
		$update[_endtime_] = $duetime;
		$update[_isent_] = "0";
		$update[_irecv_] = "0";
		$update["dlid"] = $myrow['daili'];
		$update[_i_] = "1";
		if(db(_openvpn_)->where(array(_iuser_=>$u))->update($update)){
			db("auth_kms")->where(array("id"=>$myrow['id']))->update(array("isuse"=>"1","user"=>$u,"usetime"=>date("Y-m-d H:i:s",time())));
			die('开通成功！');
		}else{
			die('开通失败！');
		}
	}
}
$key = explode("_",$_GET["app_key"]);
?><div class="alert alert-success" style="display:none;margin:0px;" >
		请在此输入您购买的流量卡密。
	</div>
		<center><img src="images/wm.gif" style="height:30px;width:186px;"></csnter>
				<center>-----------------------------------------</csnter>
				<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>jQuery自适应全屏BANNER焦点图</title>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/superslide.2.1.js"></script>

</head>
<body>

<style type="text/css">		
*{margin:0;padding:0;list-style:none;}
body{background:#fff;font:normal 12px/22px 宋体;width:100%;}
img{border:0;}
a{text-decoration:none;color:#333;}
a:hover{color:#1974A1;}
/* fullSlide */
.fullSlide{width:100%;position:relative;height:150px;background:#000;}
.fullSlide .bd{margin:0 auto;position:relative;z-index:0;overflow:hidden;}
.fullSlide .bd ul{width:100% !important;}
.fullSlide .bd li{width:100% !important;height:150px;overflow:hidden;text-align:center;}
.fullSlide .bd li a{display:block;height:150px;}
.fullSlide .hd{width:100%;position:absolute;z-index:1;bottom:0;left:0;height:30px;line-height:30px;}
.fullSlide .hd ul{text-align:center;}
.fullSlide .hd ul li{cursor:pointer;display:inline-block;*display:inline;zoom:1;width:42px;height:11px;margin:1px;overflow:hidden;background:#000;filter:alpha(opacity=50);opacity:0.5;line-height:999px;}
.fullSlide .hd ul .on{background:#f00;}
.fullSlide .prev,.fullSlide .next{display:block;position:absolute;z-index:1;top:50%;margin-top:-30px;left:15%;z-index:1;width:40px;height:60px;background:url(images/slider-arrow.png) -126px -137px #000 no-repeat;cursor:pointer;filter:alpha(opacity=50);opacity:0.5;display:none;}
.fullSlide .next{left:auto;right:15%;background-position:-6px -137px;}
</style>

<div class="fullSlide">
	<div class="bd">
		<ul>
			<li _src="url(images/1.jpg)" style="background:#E2025E center 0 no-repeat;"><a href="#"></a></li>
			<li _src="url(images/2.jpg)" style="background:#DED5A1 center 0 no-repeat;"><a href="#"></a></li>
			<li _src="url(images/3.jpg)" style="background:#B8CED1 center 0 no-repeat;"><a href="#"></a></li>
			
		</ul>
	</div>
	<div class="hd"><ul></ul></div>
	<span class="prev"></span>
	<span class="next"></span>
</div><!--fullSlide end-->
  
  
<script type="text/javascript">
$(".fullSlide").hover(function(){
    $(this).find(".prev,.next").stop(true, true).fadeTo("show", 0.5)
},
function(){
    $(this).find(".prev,.next").fadeOut()
});
$(".fullSlide").slide({
    titCell: ".hd ul",
    mainCell: ".bd ul",
    effect: "fold",
    autoPlay: true,
    autoPage: true,
    trigger: "click",
    startFun: function(i) {
        var curLi = jQuery(".fullSlide .bd li").eq(i);
        if ( !! curLi.attr("_src")) {
            curLi.css("background-image", curLi.attr("_src")).removeAttr("_src")
        }
    }
});
</script>
</body>
</html>
	<div style="margin:50px">
				<div class="form-group">
					<input type="text" class="form-control" name="km" placeholder="请输入激活码卡密">
				</div>
				<br>
				<button type="submit" class="btn btn-success btn-block cz" onclick="kmcz()">
					充值到我的账户
				</button>
				<br>
				<a target="_blank" href="http://www.917ka.com/login"class="btn btn-success btn-block cz" >
					★购买充值卡密★
				</a>
		
		<br />
			【使用说明】
			<br />
			* 充值会<span style="color:red">清空剩余流量</span>，并重设为购买的流量。时间将会设置会重置即日起到充值卡指定的日期结束，超出流量无需补交。
			<br />
			<center><b><span style="color:red"><img src="images/123.gif" style="height:18px;width:18px;">  流&nbsp;&nbsp;量&nbsp;&nbsp;价&nbsp;&nbsp;格&nbsp;&nbsp;表  <img src="images/123.gif" style="height:18px;width:18px;"></span></b></csnter>
			<center>-----------------------------------------</csnter>
			<br />
			<center>☆---&nbsp;&nbsp;&nbsp;<span style="color:red">2&nbsp;G&nbsp;&nbsp;&nbsp;</span>流&nbsp;量<span style="color:red">3&nbsp;0</span>&nbsp;天&nbsp;使&nbsp;用&nbsp;时&nbsp;间&nbsp;<span style="color:red">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5&nbsp;元</span>---☆</csnter>
			<br>
			<center>☆---&nbsp;&nbsp;&nbsp;<span style="color:red">5&nbsp;G</span>&nbsp;&nbsp;&nbsp;流&nbsp;量<span style="color:red">3&nbsp;0</span>&nbsp;天&nbsp;使&nbsp;用&nbsp;时&nbsp;间&nbsp;<span style="color:red">&nbsp;&nbsp;&nbsp;1&nbsp;0&nbsp;元</span>---☆</csnter>
			<br>
			<center>☆---&nbsp;&nbsp;&nbsp;<span style="color:red">8&nbsp;G</span>&nbsp;&nbsp;&nbsp;流&nbsp;量<span style="color:red">3&nbsp;0</span>&nbsp;天&nbsp;使&nbsp;用&nbsp;时&nbsp;间&nbsp;<span style="color:red">&nbsp;&nbsp;&nbsp;1&nbsp;5&nbsp;元</span>---☆</csnter>
			<br>
			<center>☆---&nbsp;<span style="color:red">10&nbsp;G</span>&nbsp;&nbsp;&nbsp;流&nbsp;量<span style="color:red">3&nbsp;0</span>&nbsp;天&nbsp;使&nbsp;用&nbsp;时&nbsp;间&nbsp;<span style="color:red">&nbsp;&nbsp;&nbsp;2&nbsp;0&nbsp;元</span>---☆</csnter>
			<br>
			<center>☆---&nbsp;&nbsp;<span style="color:red">无限</span>&nbsp;&nbsp;&nbsp;流&nbsp;量<span style="color:red">3&nbsp;0</span>&nbsp;天&nbsp;使&nbsp;用&nbsp;时&nbsp;间&nbsp;<span style="color:red">&nbsp;&nbsp;&nbsp;5&nbsp;0&nbsp;元</span>---☆</csnter>
			<br>
			<center>-----------------------------------------</csnter>
			</div>
			
			</div>
			
 <script>
 var old_html = "";
 function kmcz(){
	 if($("[name=km]").val() == ""){
		 $(".alert").html("卡密不能为空").show();
	 }else{
		 old_html = $(".cz").html();
		 $(".cz").html("处理中...");
		 $.post("?act=Shop&username=<?php echo $_GET['username']?>&password=<?php echo $_GET['password']?>&app_key=<?php echo $_GET['app_key']?>",{
			 "km":$("[name=km]").val()
		 },function(data){
			 $(".cz").html(old_html);
			  $(".alert").show();
			  $(".alert").html(data);
		 })
	 }
 }
 </script>