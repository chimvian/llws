<?php
/*
	测试账号申请
*/
require('head.php');
require('nav.php');
function unsetLine($arr){
	foreach($arr as $v){
		if(strpos($v,"apache") === 0){
			
		}else{
			$line[] = $v;
		}
	}
	return $line;
}
?>

   <body>
      <?php
	  $db = db('openvpn');
	  
	  $list = $db->select();
	  $i = 0;
	  $j = 0;
	  foreach($list as $vo){
		  $count += $vo[_maxll_]; // 总计流量
		  $send += $vo[_isent_]; //发送流量
		  $recv += $vo[_irecv_]; //接收流量
		  
			if($vo['i'] != '1'){
				$j++;
			}
		  
		  $i++;
	  }
	  
	  $fenpei = printmb($count);  //总计分配
	  $fasong = printmb($send);  //总计发送
	  $jieshou = printmb($recv);  //总计接收
	
	  $shiyong = printmb($send+$recv);  //总计使用
	  $weiyong = printmb($count-$send-$recv);  //总计未使用
	  //echo '服务器总共分配流量:'.round($MB['n'],2).$MB['p'];?>
	  <div class="alert alert-warning">以下信息仅供参考 因系统差异可能有误 请勿以此为维护唯一依据</div>
	  
	  <?php
	  if(is_dir("../phpmyadmin")){
		  echo '<span class="glyphicon glyphicon-exclamation-sign" style="color: rgb(255, 41, 60);">&nbsp;高危风险：检测到您的数据库管理路径为默认phpmyadmin 请立即修改</span><br>';
	  } 
	  
	  if(_pass_=="root" || _pass_=="123456" || _pass_=="Dmgsql"){
		  echo '<span class="glyphicon glyphicon-exclamation-sign" style="color: rgb(255, 41, 60);">&nbsp;高危风险：检测到您的数据库密码过于简单 请及时修改</span><br>';
	  }
	  
	  if(_pass_==_user_ ){
		  echo '<span class="glyphicon glyphicon-exclamation-sign" style="color: rgb(255, 41, 60);">&nbsp;高危风险：数据库账户与密码相同 请及时修改</span><br>';
	  }
	  ?>
	  
	  <h3>OPENVPN进程</h3>
	  <h6><b>*</b>检测您的服务器启动的openvpn进程</h6>
	  <?php
	  exec(" ps -aux |grep openvpn | grep \"config\"",$c);
	 $c = unsetLine($c);
	 foreach($c as $v){
		 echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">OPENVPN</span>&nbsp;<b>'.$v."</b></div>";
	 }
	 ?>
	 <hr>
	  <h3>监控运行</h3>
	  <h6><b>*</b>检测您的流控提供的监控运行情况(目前只能检测到大猫康师傅等)</h6>
	 <?php
	 exec(" ps aux|grep /jiankong",$jiankong);
	$jiankong = unsetLine($jiankong);
	 foreach($jiankong as $v){
		 echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">监控运行中</span>&nbsp;<b>'.$v."</b></div>";
	 }
	  ?>
	  <hr>
	  <h3>TCP端口监听</h3>
	  <h6><b>*</b>您的系统目前以对如下TCP端口进行了监听</h6>
	 <?php
	 exec(" netstat -nap|grep tcp|grep \"0 0.0.0.0:\"",$tcp);
	$tcp = unsetLine($tcp);
	 foreach($tcp as $v){
		 $v = preg_replace("/\:([0-9]*)/",":<b style=\"color:red\">$1</b>",$v);
		 echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">TCP</span>&nbsp;<b>'.$v."</b></div>";
	 }
	  ?>
	  <hr>
	  <h3>UDP端口监听</h3>
	  <h6><b>*</b>您的系统目前以对如下UDP端口进行了监听</h6>
	 <?php
	 exec(" netstat -nap|grep udp|grep \"0 0.0.0.0:\"",$udp);
	$udp = unsetLine($udp);
	 foreach($udp as $v){
		 $v = preg_replace("/\:([0-9]*)/",":<b style=\"color:red\">$1</b>",$v);
		 echo '<div style="border-bottom:1px dashed #ccc;margin-bottom:10px;"><span class="label label-info">UDP</span>&nbsp;<b>'.$v."</b></div>";
	 }
	  ?>
	  
     
 <?php
 include("footer.php");
 ?>