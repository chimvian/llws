<?php if(!defined('INCLUDE_PATH')){die('error!this is a cache file!');};?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, user-scalable=no, maximum-scale=1.0"/>
<title>叮咚猫-网罗精彩好电影-电影大全|BT下载</title>
<style type="text/css">
body,html {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	background-color: #f8f8f8;
	font-family:"微软雅黑";

}
*{
	}
ul,li,h1,h2,h3{
	padding:0px;
	margin:0px;
	list-style:none;
	font-size:1em}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
body,td,th {
	font-size: 14px;
}
.head{
	position:fixed;
	top:0px;
	width:100%;
	z-index:999;
	}
.head-nav{
	height:50px;
	line-height:50px;
	font-size:23px;
	font-weight:bolder;
	color:#fff;
	padding-left:20px;
	background:#328cc9;
	border-bottom:1px solid #ccc;
	}
.clear-style{
	list-style:none;
	padding:0;
	margin:0;
	clear:both;
	}

.head-bar{
	height:40px;
	background:#efefef;
	border-bottom:1px solid #ccc;
	}

.head-bar ul li{
	float:left;
	width:25%;
	height:50px;
	}
.head-bar ul li a{
	float:left;
	color:#222;
	text-align:center;
	line-height:40px;
	width:100%;
	}
.vide{
	background:#f8f8f8;
}
.video li{
	width:100px;
	margin:10px;
	float:left;
	background:#efefef;
	height:150px;
	}
.video li a{
	float:left;
	position:relative;
	width:100%;
	}
.video li img{
	width:100%;
	height:150px;}
.main{
	max-width:1000px;
	margin:auto;
	min-width:300px;
	}
.v-title{
	height:30px;
	background:#222;
	color:#fff;
	text-align:center;
	line-height:30px;
	position:absolute;
	bottom:0px;
	font-size:14px;
	width:100%;
	clear:both;
	}
.v-h2{
	padding:15px 10px;display:block;border-bottom:1px solid #efefef;background:#ccc;
	}
.v-h2 a{
	font-size:25px;color:#222;
	font-family:"楷体";
	}
.clear{clear:both}
</style>
</head>
<script src="http://public.dingd.cn/js/jquery.js"></script>
<body onload="setWidth()" onresize="setWidth()">
<!--网页头部-->

<div class="head">
<div class="head-nav">
叮咚猫
</div>
<!--网页底部-->
<div class="head-bar">
	<ul class="clear-style">
    	<li><a href="#">社区</a></li>
        <li><a href="#">专题</a></li>
        <li><a href="#">频道</a></li>
        <li><a href="#">搜索</a></li>
    </ul>
</div>
</div>
<div style="height:90px;"></div>
<!--视频列表-->
<div class="main">
<h2 class="v-h2"><a href="#">佳片推荐</a></h2>
<ul class="video">
	<li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
   <li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
</ul>
<div class="clear"></div>
<h2 class="v-h2"><a href="#">最新上架</a></h2>
<ul class="video">
	<li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
   <li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
</ul><div class="clear"></div>
<h2 class="v-h2"><a href="#">热点观看</a></h2>
<ul class="video">
	<li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
   <li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li><li><a href="#"><img src="m.jpg"><div class="v-title">美人鱼</div></a></li>
</ul>
</div>
<!--列表结束-->
<script>
function setWidth(){
	var n= $('.main').width();
	var w = (n-60)/3;
	var b = 150/360;
	$('.video li').css({'width':w+'px'});
	$('.video li').css({'height':(b*n)+'px'});
	$('.video li img').css({'height':(b*n)+'px'});
	}
</script>
</body>
</html>
